namespace KutuphaneWeb.Models
{
    public class ReadenBooks
    {
        public int RId { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}