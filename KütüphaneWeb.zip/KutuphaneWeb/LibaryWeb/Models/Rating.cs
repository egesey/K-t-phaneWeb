
namespace KutuphaneWeb.Models

{
    public class Rating
    {
        public int RaId { get; set; }
        public string? Name { get; set; }
        public float Ratings { get; set; }
    }
}
