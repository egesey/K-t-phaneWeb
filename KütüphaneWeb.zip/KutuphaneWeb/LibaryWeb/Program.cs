var builder = WebApplication.CreateBuilder(args);

// MVC Controller ve View desteği ekle
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Hata sayfası ve HSTS
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

//app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// Varsayılan route: Book/Index
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Book}/{action=Index}/{id?}");

app.Run();